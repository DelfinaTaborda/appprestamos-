"use client"

import { useState, useEffect } from "react"
import type { Socio } from "@/lib/types"
import { obtenerResumenMensual, formatearMoneda, formatearPorcentaje } from "@/lib/utils-app"
import { MobileNavigation } from "@/components/mobile-navigation"
import { MobileHeader } from "@/components/mobile-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { BarChart3, TrendingUp, Users, DollarSign, PieChart, Activity } from "lucide-react"

export default function ReportesPage() {
  const [socios, setSocios] = useState<Socio[]>([])

  useEffect(() => {
    const sociosGuardados = localStorage.getItem("socios")
    if (sociosGuardados) {
      setSocios(JSON.parse(sociosGuardados))
    }
  }, [])

  const resumen = obtenerResumenMensual(socios)
  const sociosActivos = socios.filter((s) => s.estado === "activo")
  const sociosPasivos = socios.filter((s) => s.estado === "pasivo")

  // Estadísticas por tipo de préstamo
  const estadisticasPorTipo = Object.entries(resumen.comisionesPorTipo)
    .map(([tipo, data]) => ({
      tipo,
      cantidad: data.cantidad,
      total: data.total,
      porcentaje: resumen.totalGeneral > 0 ? (data.total / resumen.totalGeneral) * 100 : 0,
    }))
    .sort((a, b) => b.total - a.total)

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <MobileHeader title="Reportes" />

      <main className="px-4 py-6 space-y-6">
        {/* Métricas principales */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="shadow-pink border-pink">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">Total Socios</CardTitle>
                <Users className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-gradient-pink">{resumen.totalSocios}</div>
              <p className="text-xs text-muted-foreground">
                {resumen.sociosActivos} activos, {sociosPasivos.length} pasivos
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-pink border-pink">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">Comisiones</CardTitle>
                <DollarSign className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-gradient-pink">{formatearMoneda(resumen.totalGeneral)}</div>
              <p className="text-xs text-muted-foreground">Solo activos</p>
            </CardContent>
          </Card>

          <Card className="shadow-pink border-pink">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">Nuevos</CardTitle>
                <TrendingUp className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-gradient-pink">{resumen.sociosNuevos}</div>
              <p className="text-xs text-muted-foreground">Este mes</p>
            </CardContent>
          </Card>

          <Card className="shadow-pink border-pink">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">Promedio</CardTitle>
                <BarChart3 className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-gradient-pink">
                {formatearMoneda(resumen.sociosActivos > 0 ? resumen.totalGeneral / resumen.sociosActivos : 0)}
              </div>
              <p className="text-xs text-muted-foreground">Por socio</p>
            </CardContent>
          </Card>
        </div>

        {/* Distribución por tipo de préstamo */}
        <Card className="shadow-pink border-pink">
          <CardHeader>
            <div className="flex items-center gap-2">
              <PieChart className="h-5 w-5 text-primary" />
              <CardTitle className="text-lg">Por Tipo de Préstamo</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {estadisticasPorTipo.length > 0 ? (
              estadisticasPorTipo.map((stat) => (
                <div key={stat.tipo} className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{stat.tipo}</p>
                      <p className="text-xs text-muted-foreground">{stat.cantidad} socios</p>
                    </div>
                    <div className="text-right ml-4">
                      <p className="font-medium text-sm">{formatearMoneda(stat.total)}</p>
                      <p className="text-xs text-muted-foreground">{stat.porcentaje.toFixed(1)}%</p>
                    </div>
                  </div>
                  <Progress value={stat.porcentaje} className="h-2" />
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground text-sm">No hay datos para mostrar</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Estado de socios */}
        <Card className="shadow-pink border-pink">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-primary" />
              <CardTitle className="text-lg">Estado de Socios</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-primary"></div>
                  <span className="text-sm font-medium">Activos</span>
                </div>
                <span className="font-medium text-sm">{sociosActivos.length}</span>
              </div>
              <Progress
                value={resumen.totalSocios > 0 ? (sociosActivos.length / resumen.totalSocios) * 100 : 0}
                className="h-2"
              />
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-primary/70"></div>
                  <span className="text-sm font-medium">Pasivos</span>
                </div>
                <span className="font-medium text-sm">{sociosPasivos.length}</span>
              </div>
              <Progress
                value={resumen.totalSocios > 0 ? (sociosPasivos.length / resumen.totalSocios) * 100 : 0}
                className="h-2"
              />
            </div>
          </CardContent>
        </Card>

        {/* Resumen financiero detallado */}
        <Card className="shadow-pink border-pink">
          <CardHeader>
            <div className="flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-primary" />
              <CardTitle className="text-lg">Resumen Financiero</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div className="flex items-center justify-between p-3 bg-primary/5 rounded-lg">
                <span className="text-sm font-medium">Total en Créditos</span>
                <span className="font-bold text-primary">
                  {formatearMoneda(sociosActivos.reduce((sum, s) => sum + s.monto_credito, 0))}
                </span>
              </div>
              <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                <span className="text-sm font-medium">Total en Comisiones</span>
                <span className="font-bold text-green-600">{formatearMoneda(resumen.totalGeneral)}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <span className="text-sm font-medium">Porcentaje Promedio</span>
                <span className="font-bold text-blue-600">
                  {sociosActivos.length > 0
                    ? formatearPorcentaje(
                        sociosActivos.reduce((sum, s) => sum + (s.porcentaje_comision || 0), 0) / sociosActivos.length,
                      )
                    : "0%"}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Estadísticas adicionales */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="shadow-pink border-pink">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Mayor Comisión</CardTitle>
            </CardHeader>
            <CardContent>
              {sociosActivos.length > 0 ? (
                <>
                  <div className="text-lg font-bold text-green-600">
                    {formatearMoneda(
                      Math.max(...sociosActivos.map((s) => s.monto_credito * (s.porcentaje_comision || 0))),
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">Individual</p>
                </>
              ) : (
                <div className="text-lg font-bold text-muted-foreground">$0</div>
              )}
            </CardContent>
          </Card>

          <Card className="shadow-pink border-pink">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Mayor Crédito</CardTitle>
            </CardHeader>
            <CardContent>
              {sociosActivos.length > 0 ? (
                <>
                  <div className="text-lg font-bold text-primary">
                    {formatearMoneda(Math.max(...sociosActivos.map((s) => s.monto_credito)))}
                  </div>
                  <p className="text-xs text-muted-foreground">Individual</p>
                </>
              ) : (
                <div className="text-lg font-bold text-muted-foreground">$0</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Top 3 socios por comisión */}
        {sociosActivos.length > 0 && (
          <Card className="shadow-pink border-pink">
            <CardHeader>
              <CardTitle className="text-lg">Top Socios por Comisión</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {sociosActivos
                .sort((a, b) => {
                  const comisionA = a.monto_credito * (a.porcentaje_comision || 0)
                  const comisionB = b.monto_credito * (b.porcentaje_comision || 0)
                  return comisionB - comisionA
                })
                .slice(0, 3)
                .map((socio, index) => {
                  const comision = socio.monto_credito * (socio.porcentaje_comision || 0)
                  return (
                    <div key={socio.id} className="flex items-center justify-between p-3 bg-primary/5 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white ${
                            index === 0 ? "bg-yellow-500" : index === 1 ? "bg-gray-400" : "bg-orange-500"
                          }`}
                        >
                          {index + 1}
                        </div>
                        <div>
                          <p className="font-medium text-sm truncate">{socio.nombre}</p>
                          <p className="text-xs text-muted-foreground">{socio.tipo_prestamo}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-sm text-green-600">{formatearMoneda(comision)}</p>
                        <p className="text-xs text-muted-foreground">
                          {formatearPorcentaje(socio.porcentaje_comision || 0)}
                        </p>
                      </div>
                    </div>
                  )
                })}
            </CardContent>
          </Card>
        )}
      </main>

      <MobileNavigation />
    </div>
  )
}
