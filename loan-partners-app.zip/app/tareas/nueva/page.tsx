"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import type { Tarea, Socio } from "@/lib/types"
import { MobileNavigation } from "@/components/mobile-navigation"
import { MobileHeader } from "@/components/mobile-header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Save } from "lucide-react"

export default function NuevaTareaPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [socios, setSocios] = useState<Socio[]>([])
  const [formData, setFormData] = useState({
    titulo: "",
    descripcion: "",
    fecha_vencimiento: "",
    prioridad: "media" as "baja" | "media" | "alta",
    socio_id: searchParams.get("socio_id") || "0",
  })

  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    const sociosGuardados = localStorage.getItem("socios")
    if (sociosGuardados) {
      setSocios(JSON.parse(sociosGuardados))
    }
  }, [])

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.titulo.trim()) newErrors.titulo = "El título es requerido"
    if (!formData.descripcion.trim()) newErrors.descripcion = "La descripción es requerida"
    if (!formData.fecha_vencimiento) newErrors.fecha_vencimiento = "La fecha de vencimiento es requerida"

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    const nuevaTarea: Tarea = {
      id: Date.now().toString(),
      titulo: formData.titulo.trim(),
      descripcion: formData.descripcion.trim(),
      fecha_vencimiento: formData.fecha_vencimiento,
      completada: false,
      socio_id: formData.socio_id === "0" ? undefined : formData.socio_id,
      prioridad: formData.prioridad,
      fecha_creacion: new Date().toISOString(),
    }

    // Guardar en localStorage
    const tareasExistentes = JSON.parse(localStorage.getItem("tareas") || "[]")
    const tareasActualizadas = [...tareasExistentes, nuevaTarea]
    localStorage.setItem("tareas", JSON.stringify(tareasActualizadas))

    router.push("/tareas")
  }

  const socioSeleccionado = socios.find((s) => s.id === formData.socio_id)

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <MobileHeader title="Nueva Tarea" showBack backHref="/tareas" />

      <main className="px-4 py-6">
        <Card className="shadow-pink border-pink">
          <CardHeader>
            <CardTitle className="text-lg">Información de la Tarea</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="titulo">Título *</Label>
                <Input
                  id="titulo"
                  value={formData.titulo}
                  onChange={(e) => handleInputChange("titulo", e.target.value)}
                  className={`h-12 ${errors.titulo ? "border-red-500" : ""}`}
                  placeholder="Ej: Llamar para seguimiento de pago"
                />
                {errors.titulo && <p className="text-sm text-red-500">{errors.titulo}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="descripcion">Descripción *</Label>
                <Textarea
                  id="descripcion"
                  value={formData.descripcion}
                  onChange={(e) => handleInputChange("descripcion", e.target.value)}
                  className={`resize-none ${errors.descripcion ? "border-red-500" : ""}`}
                  rows={3}
                  placeholder="Describe los detalles de la tarea..."
                />
                {errors.descripcion && <p className="text-sm text-red-500">{errors.descripcion}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fecha_vencimiento">Fecha de Vencimiento *</Label>
                  <Input
                    id="fecha_vencimiento"
                    type="datetime-local"
                    value={formData.fecha_vencimiento}
                    onChange={(e) => handleInputChange("fecha_vencimiento", e.target.value)}
                    className={`h-12 ${errors.fecha_vencimiento ? "border-red-500" : ""}`}
                  />
                  {errors.fecha_vencimiento && <p className="text-sm text-red-500">{errors.fecha_vencimiento}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="prioridad">Prioridad</Label>
                  <Select value={formData.prioridad} onValueChange={(value) => handleInputChange("prioridad", value)}>
                    <SelectTrigger className="h-12">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="baja">Baja</SelectItem>
                      <SelectItem value="media">Media</SelectItem>
                      <SelectItem value="alta">Alta</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="socio_id">Asociar con Socio (Opcional)</Label>
                <Select value={formData.socio_id} onValueChange={(value) => handleInputChange("socio_id", value)}>
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="Seleccionar socio..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Sin asociar</SelectItem>
                    {socios.map((socio) => (
                      <SelectItem key={socio.id} value={socio.id}>
                        {socio.nombre} - {socio.dni}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {socioSeleccionado && (
                  <p className="text-sm text-muted-foreground">
                    Asociada con: {socioSeleccionado.nombre} ({socioSeleccionado.telefono})
                  </p>
                )}
              </div>

              <div className="space-y-3 pt-4">
                <Button type="submit" className="w-full h-12">
                  <Save className="h-4 w-4 mr-2" />
                  Guardar Tarea
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full h-12 bg-transparent"
                  onClick={() => router.back()}
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>

      <MobileNavigation />
    </div>
  )
}
