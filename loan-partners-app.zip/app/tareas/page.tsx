"use client"

import { useState, useEffect } from "react"
import type { Tarea } from "@/lib/types"
import { MobileNavigation } from "@/components/mobile-navigation"
import { MobileHeader } from "@/components/mobile-header"
import { MobileTareaCard } from "@/components/mobile-tarea-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Search, Filter } from "lucide-react"
import Link from "next/link"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"

export default function TareasPage() {
  const [tareas, setTareas] = useState<Tarea[]>([])
  const [filtroTitulo, setFiltroTitulo] = useState("")
  const [filtroEstado, setFiltroEstado] = useState<string>("pendientes")
  const [filtroPrioridad, setFiltroPrioridad] = useState<string>("todas")

  useEffect(() => {
    const tareasGuardadas = localStorage.getItem("tareas")
    if (tareasGuardadas) {
      setTareas(JSON.parse(tareasGuardadas))
    }
  }, [])

  const tareasFiltradas = tareas.filter((tarea) => {
    const coincideTitulo =
      tarea.titulo.toLowerCase().includes(filtroTitulo.toLowerCase()) ||
      tarea.descripcion.toLowerCase().includes(filtroTitulo.toLowerCase())

    let coincideEstado = true
    if (filtroEstado === "pendientes") coincideEstado = !tarea.completada
    else if (filtroEstado === "completadas") coincideEstado = tarea.completada
    else if (filtroEstado === "vencidas") {
      coincideEstado = new Date(tarea.fecha_vencimiento) < new Date() && !tarea.completada
    }

    const coincidePrioridad = filtroPrioridad === "todas" || tarea.prioridad === filtroPrioridad

    return coincideTitulo && coincideEstado && coincidePrioridad
  })

  const handleToggleComplete = (id: string) => {
    const tareasActualizadas = tareas.map((tarea) =>
      tarea.id === id ? { ...tarea, completada: !tarea.completada } : tarea,
    )
    setTareas(tareasActualizadas)
    localStorage.setItem("tareas", JSON.stringify(tareasActualizadas))
  }

  const handleEditTarea = (tarea: Tarea) => {
    console.log("Editar tarea:", tarea)
  }

  // Ordenar tareas: vencidas primero, luego por fecha de vencimiento
  const tareasOrdenadas = tareasFiltradas.sort((a, b) => {
    const fechaA = new Date(a.fecha_vencimiento)
    const fechaB = new Date(b.fecha_vencimiento)
    const hoy = new Date()

    const aVencida = fechaA < hoy && !a.completada
    const bVencida = fechaB < hoy && !b.completada

    if (aVencida && !bVencida) return -1
    if (!aVencida && bVencida) return 1

    return fechaA.getTime() - fechaB.getTime()
  })

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <MobileHeader title="Tareas" showAdd addHref="/tareas/nueva" addLabel="Nueva" />

      <main className="px-4 py-6 space-y-4">
        {/* Barra de búsqueda y filtros */}
        <div className="space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Buscar tareas..."
              value={filtroTitulo}
              onChange={(e) => setFiltroTitulo(e.target.value)}
              className="pl-10 h-12"
            />
          </div>

          {/* Filtros en móvil */}
          <div className="flex gap-2">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtros
                </Button>
              </SheetTrigger>
              <SheetContent side="bottom" className="h-[300px]">
                <SheetHeader>
                  <SheetTitle>Filtrar Tareas</SheetTitle>
                </SheetHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <label className="text-sm font-medium">Estado</label>
                    <Select value={filtroEstado} onValueChange={setFiltroEstado}>
                      <SelectTrigger>
                        <SelectValue placeholder="Estado" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todas">Todas</SelectItem>
                        <SelectItem value="pendientes">Pendientes</SelectItem>
                        <SelectItem value="completadas">Completadas</SelectItem>
                        <SelectItem value="vencidas">Vencidas</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Prioridad</label>
                    <Select value={filtroPrioridad} onValueChange={setFiltroPrioridad}>
                      <SelectTrigger>
                        <SelectValue placeholder="Prioridad" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todas">Todas</SelectItem>
                        <SelectItem value="alta">Alta</SelectItem>
                        <SelectItem value="media">Media</SelectItem>
                        <SelectItem value="baja">Baja</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Resultados */}
        <div className="text-sm text-muted-foreground">
          {tareasFiltradas.length} de {tareas.length} tareas
        </div>

        {/* Lista de tareas */}
        {tareasOrdenadas.length > 0 ? (
          <div className="space-y-3">
            {tareasOrdenadas.map((tarea) => (
              <MobileTareaCard
                key={tarea.id}
                tarea={tarea}
                onToggleComplete={handleToggleComplete}
                onEdit={handleEditTarea}
              />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <p className="text-muted-foreground mb-4 text-center">
                {tareas.length === 0
                  ? "No hay tareas registradas"
                  : "No se encontraron tareas con los filtros aplicados"}
              </p>
              {tareas.length === 0 && (
                <Button asChild>
                  <Link href="/tareas/nueva">Crear primera tarea</Link>
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </main>

      <MobileNavigation />
    </div>
  )
}
