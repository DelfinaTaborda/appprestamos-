"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import type { Socio } from "@/lib/types"
import { COMISIONES_POR_TIPO, TIPOS_PRESTAMO } from "@/lib/data"
import { Navigation } from "@/components/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Save, Trash2 } from "lucide-react"
import Link from "next/link"

export default function EditarSocioPage() {
  const params = useParams()
  const router = useRouter()
  const [socio, setSocio] = useState<Socio | null>(null)
  const [formData, setFormData] = useState({
    nombre: "",
    dni: "",
    telefono: "",
    direccion: "",
    estado: "activo" as "activo" | "pasivo",
    tipo_prestamo: "" as keyof typeof COMISIONES_POR_TIPO,
    monto_credito: "",
    fecha_otorgamiento: "",
    porcentaje_comision: "",
    observaciones: "",
  })

  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    const sociosGuardados = localStorage.getItem("socios")
    if (sociosGuardados) {
      const socios = JSON.parse(sociosGuardados)
      const socioEncontrado = socios.find((s: Socio) => s.id === params.id)
      if (socioEncontrado) {
        setSocio(socioEncontrado)
        setFormData({
          nombre: socioEncontrado.nombre,
          dni: socioEncontrado.dni,
          telefono: socioEncontrado.telefono,
          direccion: socioEncontrado.direccion,
          estado: socioEncontrado.estado,
          tipo_prestamo: socioEncontrado.tipo_prestamo,
          monto_credito: socioEncontrado.monto_credito.toString(),
          fecha_otorgamiento: socioEncontrado.fecha_otorgamiento,
          porcentaje_comision: socioEncontrado.porcentaje_comision
            ? (socioEncontrado.porcentaje_comision * 100).toString()
            : "",
          observaciones: socioEncontrado.observaciones || "",
        })
      }
    }
  }, [params.id])

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }

    // Auto-completar porcentaje de comisión cuando se selecciona tipo de préstamo
    if (field === "tipo_prestamo" && value) {
      const porcentajeDefecto = COMISIONES_POR_TIPO[value as keyof typeof COMISIONES_POR_TIPO]?.porcentaje_por_defecto
      if (porcentajeDefecto) {
        setFormData((prev) => ({
          ...prev,
          [field]: value,
          porcentaje_comision: (porcentajeDefecto * 100).toString(),
        }))
      }
    }

    // Validar DNI en tiempo real
    if (field === "dni" && value) {
      const dniLimpio = value.replace(/\D/g, "").slice(0, 8)
      setFormData((prev) => ({ ...prev, [field]: dniLimpio }))
      return
    }

    // Validar teléfono en tiempo real
    if (field === "telefono" && value) {
      const telefonoLimpio = value.replace(/[^\d\-+$$$$\s]/g, "")
      setFormData((prev) => ({ ...prev, [field]: telefonoLimpio }))
      return
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.nombre.trim()) newErrors.nombre = "El nombre es requerido"
    if (!formData.dni.trim()) newErrors.dni = "El DNI es requerido"
    if (!formData.telefono.trim()) newErrors.telefono = "El teléfono es requerido"
    if (!formData.direccion.trim()) newErrors.direccion = "La dirección es requerida"
    if (!formData.tipo_prestamo) newErrors.tipo_prestamo = "El tipo de préstamo es requerido"
    if (!formData.monto_credito || Number.parseFloat(formData.monto_credito) <= 0) {
      newErrors.monto_credito = "El monto de crédito debe ser mayor a 0"
    }
    if (!formData.fecha_otorgamiento) newErrors.fecha_otorgamiento = "La fecha de otorgamiento es requerida"

    // Validar DNI único (excluyendo el socio actual)
    const sociosExistentes = JSON.parse(localStorage.getItem("socios") || "[]")
    const dniExiste = sociosExistentes.some((s: Socio) => s.dni === formData.dni.trim() && s.id !== params.id)
    if (dniExiste) newErrors.dni = "Ya existe otro socio con este DNI"

    // Validar formato de DNI
    if (formData.dni.trim().length < 7 || formData.dni.trim().length > 8) {
      newErrors.dni = "El DNI debe tener entre 7 y 8 dígitos"
    }

    // Validar porcentaje
    if (
      formData.porcentaje_comision &&
      (Number.parseFloat(formData.porcentaje_comision) <= 0 || Number.parseFloat(formData.porcentaje_comision) > 100)
    ) {
      newErrors.porcentaje_comision = "El porcentaje debe estar entre 0.1% y 100%"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm() || !socio) return

    const socioActualizado: Socio = {
      ...socio,
      nombre: formData.nombre.trim(),
      dni: formData.dni.trim(),
      telefono: formData.telefono.trim(),
      direccion: formData.direccion.trim(),
      estado: formData.estado,
      tipo_prestamo: formData.tipo_prestamo,
      monto_credito: Number.parseFloat(formData.monto_credito),
      fecha_otorgamiento: formData.fecha_otorgamiento,
      porcentaje_comision: formData.porcentaje_comision
        ? Number.parseFloat(formData.porcentaje_comision) / 100
        : undefined,
      observaciones: formData.observaciones.trim() || undefined,
    }

    // Actualizar en localStorage
    const sociosExistentes = JSON.parse(localStorage.getItem("socios") || "[]")
    const sociosActualizados = sociosExistentes.map((s: Socio) => (s.id === socio.id ? socioActualizado : s))
    localStorage.setItem("socios", JSON.stringify(sociosActualizados))

    router.push(`/socios/${socio.id}`)
  }

  const handleDelete = () => {
    if (!socio) return

    const confirmar = window.confirm(
      `¿Estás seguro de que quieres eliminar al socio ${socio.nombre}? Esta acción no se puede deshacer.`,
    )

    if (confirmar) {
      const sociosExistentes = JSON.parse(localStorage.getItem("socios") || "[]")
      const sociosActualizados = sociosExistentes.filter((s: Socio) => s.id !== socio.id)
      localStorage.setItem("socios", JSON.stringify(sociosActualizados))

      // También eliminar tareas asociadas
      const tareasExistentes = JSON.parse(localStorage.getItem("tareas") || "[]")
      const tareasActualizadas = tareasExistentes.filter((t: any) => t.socio_id !== socio.id)
      localStorage.setItem("tareas", JSON.stringify(tareasActualizadas))

      router.push("/socios")
    }
  }

  const porcentajesDisponibles = formData.tipo_prestamo
    ? COMISIONES_POR_TIPO[formData.tipo_prestamo]?.porcentajes_posibles || []
    : []

  if (!socio) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/socios">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Volver
                  </Link>
                </Button>
                <h1 className="text-2xl font-bold">Socio no encontrado</h1>
              </div>
              <Navigation />
            </div>
          </div>
        </header>
        <main className="container mx-auto px-4 py-8">
          <Card>
            <CardContent className="flex items-center justify-center py-12">
              <p className="text-muted-foreground">El socio solicitado no existe</p>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href={`/socios/${socio.id}`}>
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Volver
                </Link>
              </Button>
              <h1 className="text-2xl font-bold">Editar Socio</h1>
            </div>
            <Navigation />
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Card className="max-w-2xl mx-auto shadow-pink border-pink">
          <CardHeader>
            <CardTitle>Editar Información del Socio</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Información personal */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nombre">Nombre *</Label>
                  <Input
                    id="nombre"
                    value={formData.nombre}
                    onChange={(e) => handleInputChange("nombre", e.target.value)}
                    className={errors.nombre ? "border-red-500" : ""}
                  />
                  {errors.nombre && <p className="text-sm text-red-500">{errors.nombre}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dni">DNI *</Label>
                  <Input
                    id="dni"
                    value={formData.dni}
                    onChange={(e) => handleInputChange("dni", e.target.value)}
                    className={errors.dni ? "border-red-500" : ""}
                    placeholder="12345678"
                    maxLength={8}
                  />
                  {errors.dni && <p className="text-sm text-red-500">{errors.dni}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="telefono">Teléfono *</Label>
                  <Input
                    id="telefono"
                    value={formData.telefono}
                    onChange={(e) => handleInputChange("telefono", e.target.value)}
                    className={errors.telefono ? "border-red-500" : ""}
                    placeholder="11-1234-5678"
                  />
                  {errors.telefono && <p className="text-sm text-red-500">{errors.telefono}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="estado">Estado *</Label>
                  <Select value={formData.estado} onValueChange={(value) => handleInputChange("estado", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="activo">Activo</SelectItem>
                      <SelectItem value="pasivo">Pasivo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="direccion">Dirección *</Label>
                <Input
                  id="direccion"
                  value={formData.direccion}
                  onChange={(e) => handleInputChange("direccion", e.target.value)}
                  className={errors.direccion ? "border-red-500" : ""}
                />
                {errors.direccion && <p className="text-sm text-red-500">{errors.direccion}</p>}
              </div>

              {/* Información del préstamo */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tipo_prestamo">Tipo de Préstamo *</Label>
                  <Select
                    value={formData.tipo_prestamo}
                    onValueChange={(value) => handleInputChange("tipo_prestamo", value)}
                  >
                    <SelectTrigger className={errors.tipo_prestamo ? "border-red-500" : ""}>
                      <SelectValue placeholder="Seleccionar tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      {TIPOS_PRESTAMO.map((tipo) => (
                        <SelectItem key={tipo} value={tipo}>
                          {tipo}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.tipo_prestamo && <p className="text-sm text-red-500">{errors.tipo_prestamo}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="monto_credito">Monto de Crédito *</Label>
                  <Input
                    id="monto_credito"
                    type="number"
                    step="0.01"
                    value={formData.monto_credito}
                    onChange={(e) => handleInputChange("monto_credito", e.target.value)}
                    className={errors.monto_credito ? "border-red-500" : ""}
                  />
                  {errors.monto_credito && <p className="text-sm text-red-500">{errors.monto_credito}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="fecha_otorgamiento">Fecha de Otorgamiento *</Label>
                  <Input
                    id="fecha_otorgamiento"
                    type="date"
                    value={formData.fecha_otorgamiento}
                    onChange={(e) => handleInputChange("fecha_otorgamiento", e.target.value)}
                    className={errors.fecha_otorgamiento ? "border-red-500" : ""}
                  />
                  {errors.fecha_otorgamiento && <p className="text-sm text-red-500">{errors.fecha_otorgamiento}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="porcentaje_comision">Porcentaje de Comisión (%)</Label>
                  <div className="relative">
                    <Input
                      id="porcentaje_comision"
                      type="number"
                      step="0.1"
                      min="0"
                      max="100"
                      value={formData.porcentaje_comision}
                      onChange={(e) => handleInputChange("porcentaje_comision", e.target.value)}
                      placeholder="Ej: 7.0"
                      className="pr-12"
                    />
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                      <span className="text-sm text-muted-foreground">%</span>
                    </div>
                  </div>
                  {formData.tipo_prestamo && (
                    <div className="text-xs text-muted-foreground">
                      Sugerido para {formData.tipo_prestamo}:{" "}
                      {porcentajesDisponibles.map((p, index) => (
                        <button
                          key={p}
                          type="button"
                          onClick={() => handleInputChange("porcentaje_comision", (p * 100).toString())}
                          className="text-primary hover:underline mr-2"
                        >
                          {(p * 100).toFixed(1)}%{index < porcentajesDisponibles.length - 1 ? "," : ""}
                        </button>
                      ))}
                    </div>
                  )}
                  {errors.porcentaje_comision && <p className="text-sm text-red-500">{errors.porcentaje_comision}</p>}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="observaciones">Observaciones</Label>
                <Textarea
                  id="observaciones"
                  value={formData.observaciones}
                  onChange={(e) => handleInputChange("observaciones", e.target.value)}
                  rows={3}
                />
              </div>

              <div className="flex gap-4 pt-4">
                <Button type="submit" className="flex-1">
                  <Save className="h-4 w-4 mr-2" />
                  Guardar Cambios
                </Button>
                <Button type="button" variant="outline" asChild>
                  <Link href={`/socios/${socio.id}`}>Cancelar</Link>
                </Button>
                <Button type="button" variant="destructive" onClick={handleDelete}>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Eliminar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
