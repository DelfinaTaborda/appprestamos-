"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import type { Socio, Tarea } from "@/lib/types"
import { calcularComision, formatearMoneda, formatearPorcentaje } from "@/lib/utils-app"
import { Navigation } from "@/components/navigation"
import { TareaCard } from "@/components/tarea-card"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft, Edit, Phone, MapPin, Calendar, DollarSign, Percent, FileText } from "lucide-react"
import Link from "next/link"

export default function SocioDetailPage() {
  const params = useParams()
  const [socio, setSocio] = useState<Socio | null>(null)
  const [tareas, setTareas] = useState<Tarea[]>([])

  useEffect(() => {
    const sociosGuardados = localStorage.getItem("socios")
    const tareasGuardadas = localStorage.getItem("tareas")

    if (sociosGuardados) {
      const socios = JSON.parse(sociosGuardados)
      const socioEncontrado = socios.find((s: Socio) => s.id === params.id)
      setSocio(socioEncontrado || null)
    }

    if (tareasGuardadas) {
      const todasLasTareas = JSON.parse(tareasGuardadas)
      const tareasDelSocio = todasLasTareas.filter((t: Tarea) => t.socio_id === params.id)
      setTareas(tareasDelSocio)
    }
  }, [params.id])

  const handleToggleComplete = (id: string) => {
    const tareasActualizadas = tareas.map((tarea) =>
      tarea.id === id ? { ...tarea, completada: !tarea.completada } : tarea,
    )
    setTareas(tareasActualizadas)

    // Actualizar en localStorage
    const todasLasTareas = JSON.parse(localStorage.getItem("tareas") || "[]")
    const tareasGlobalesActualizadas = todasLasTareas.map((t: Tarea) =>
      t.id === id ? { ...t, completada: !t.completada } : t,
    )
    localStorage.setItem("tareas", JSON.stringify(tareasGlobalesActualizadas))
  }

  if (!socio) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/socios">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Volver
                  </Link>
                </Button>
                <h1 className="text-2xl font-bold">Socio no encontrado</h1>
              </div>
              <Navigation />
            </div>
          </div>
        </header>
        <main className="container mx-auto px-4 py-8">
          <Card>
            <CardContent className="flex items-center justify-center py-12">
              <p className="text-muted-foreground">El socio solicitado no existe</p>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  const comision = calcularComision(socio)
  const tareasPendientes = tareas.filter((t) => !t.completada)
  const tareasCompletadas = tareas.filter((t) => t.completada)

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/socios">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Volver
                </Link>
              </Button>
              <h1 className="text-2xl font-bold">{socio.nombre}</h1>
            </div>
            <Navigation />
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="space-y-8">
          {/* Información principal */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader className="flex flex-row items-start justify-between">
                  <div>
                    <CardTitle className="text-2xl">{socio.nombre}</CardTitle>
                    <p className="text-muted-foreground">DNI: {socio.dni}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={socio.estado === "activo" ? "default" : "secondary"}>{socio.estado}</Badge>
                    <Button size="sm" asChild>
                      <Link href={`/socios/${socio.id}/editar`}>
                        <Edit className="h-4 w-4 mr-2" />
                        Editar
                      </Link>
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Información de contacto */}
                  <div className="space-y-4">
                    <h3 className="font-semibold">Información de Contacto</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        <span>{socio.telefono}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span>{socio.direccion}</span>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Información del préstamo */}
                  <div className="space-y-4">
                    <h3 className="font-semibold">Información del Préstamo</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Tipo de Préstamo</p>
                            <p className="font-medium">{socio.tipo_prestamo}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <DollarSign className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Monto de Crédito</p>
                            <p className="font-medium">{formatearMoneda(socio.monto_credito)}</p>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Fecha de Otorgamiento</p>
                            <p className="font-medium">
                              {new Date(socio.fecha_otorgamiento).toLocaleDateString("es-AR")}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Percent className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Porcentaje de Comisión</p>
                            <p className="font-medium">{formatearPorcentaje(socio.porcentaje_comision || 0)}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {socio.observaciones && (
                    <>
                      <Separator />
                      <div className="space-y-2">
                        <h3 className="font-semibold">Observaciones</h3>
                        <p className="text-muted-foreground">{socio.observaciones}</p>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Resumen financiero */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Resumen Financiero</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">{formatearMoneda(comision)}</p>
                    <p className="text-sm text-muted-foreground">Comisión Total</p>
                  </div>
                  <Separator />
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Monto Base:</span>
                      <span className="text-sm font-medium">{formatearMoneda(socio.monto_credito)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Porcentaje:</span>
                      <span className="text-sm font-medium">{formatearPorcentaje(socio.porcentaje_comision || 0)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Estadísticas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Tareas Totales:</span>
                    <span className="text-sm font-medium">{tareas.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Pendientes:</span>
                    <span className="text-sm font-medium text-orange-600">{tareasPendientes.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Completadas:</span>
                    <span className="text-sm font-medium text-green-600">{tareasCompletadas.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Días como socio:</span>
                    <span className="text-sm font-medium">
                      {Math.floor(
                        (new Date().getTime() - new Date(socio.fecha_creacion).getTime()) / (1000 * 60 * 60 * 24),
                      )}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Tareas asociadas */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Tareas Asociadas</CardTitle>
              <Button size="sm" asChild>
                <Link href={`/tareas/nueva?socio_id=${socio.id}`}>Agregar Tarea</Link>
              </Button>
            </CardHeader>
            <CardContent>
              {tareas.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {tareas
                    .sort((a, b) => new Date(a.fecha_vencimiento).getTime() - new Date(b.fecha_vencimiento).getTime())
                    .map((tarea) => (
                      <TareaCard key={tarea.id} tarea={tarea} onToggleComplete={handleToggleComplete} />
                    ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground mb-4">No hay tareas asociadas a este socio</p>
                  <Button asChild>
                    <Link href={`/tareas/nueva?socio_id=${socio.id}`}>Crear primera tarea</Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
