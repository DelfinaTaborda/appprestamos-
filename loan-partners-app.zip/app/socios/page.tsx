"use client"

import { useState, useEffect } from "react"
import type { Socio } from "@/lib/types"
import { MobileNavigation } from "@/components/mobile-navigation"
import { MobileHeader } from "@/components/mobile-header"
import { MobileSocioCard } from "@/components/mobile-socio-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Search, Filter } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"

export default function SociosPage() {
  const [socios, setSocios] = useState<Socio[]>([])
  const [filtroNombre, setFiltroNombre] = useState("")
  const [filtroEstado, setFiltroEstado] = useState<string>("todos")
  const [filtroTipo, setFiltroTipo] = useState<string>("todos")
  const router = useRouter()

  useEffect(() => {
    const sociosGuardados = localStorage.getItem("socios")
    if (sociosGuardados) {
      setSocios(JSON.parse(sociosGuardados))
    }
  }, [])

  const sociosFiltrados = socios.filter((socio) => {
    const coincideNombre =
      socio.nombre.toLowerCase().includes(filtroNombre.toLowerCase()) || socio.dni.includes(filtroNombre)
    const coincideEstado = filtroEstado === "todos" || socio.estado === filtroEstado
    const coincideTipo = filtroTipo === "todos" || socio.tipo_prestamo === filtroTipo

    return coincideNombre && coincideEstado && coincideTipo
  })

  const handleEditSocio = (socio: Socio) => {
    router.push(`/socios/${socio.id}/editar`)
  }

  const tiposUnicos = [...new Set(socios.map((s) => s.tipo_prestamo))]

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <MobileHeader title="Socios" showAdd addHref="/socios/nuevo" addLabel="Nuevo" />

      <main className="px-4 py-6 space-y-4">
        {/* Barra de búsqueda y filtros */}
        <div className="space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Buscar por nombre o DNI..."
              value={filtroNombre}
              onChange={(e) => setFiltroNombre(e.target.value)}
              className="pl-10 h-12"
            />
          </div>

          {/* Filtros en móvil */}
          <div className="flex gap-2">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtros
                </Button>
              </SheetTrigger>
              <SheetContent side="bottom" className="h-[300px]">
                <SheetHeader>
                  <SheetTitle>Filtrar Socios</SheetTitle>
                </SheetHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <label className="text-sm font-medium">Estado</label>
                    <Select value={filtroEstado} onValueChange={setFiltroEstado}>
                      <SelectTrigger>
                        <SelectValue placeholder="Estado" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todos">Todos</SelectItem>
                        <SelectItem value="activo">Activo</SelectItem>
                        <SelectItem value="pasivo">Pasivo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Tipo de Préstamo</label>
                    <Select value={filtroTipo} onValueChange={setFiltroTipo}>
                      <SelectTrigger>
                        <SelectValue placeholder="Tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todos">Todos</SelectItem>
                        {tiposUnicos.map((tipo) => (
                          <SelectItem key={tipo} value={tipo}>
                            {tipo}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Resultados */}
        <div className="text-sm text-muted-foreground">
          {sociosFiltrados.length} de {socios.length} socios
        </div>

        {/* Lista de socios */}
        {sociosFiltrados.length > 0 ? (
          <div className="space-y-3">
            {sociosFiltrados.map((socio) => (
              <MobileSocioCard key={socio.id} socio={socio} onEdit={handleEditSocio} />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <p className="text-muted-foreground mb-4 text-center">
                {socios.length === 0
                  ? "No hay socios registrados"
                  : "No se encontraron socios con los filtros aplicados"}
              </p>
              {socios.length === 0 && (
                <Button asChild>
                  <Link href="/socios/nuevo">Agregar primer socio</Link>
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </main>

      <MobileNavigation />
    </div>
  )
}
