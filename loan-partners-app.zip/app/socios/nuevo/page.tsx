"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import type { Socio } from "@/lib/types"
import { COMISIONES_POR_TIPO, TIPOS_PRESTAMO } from "@/lib/data"
import { MobileNavigation } from "@/components/mobile-navigation"
import { MobileHeader } from "@/components/mobile-header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Save } from "lucide-react"

export default function NuevoSocioPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    nombre: "",
    dni: "",
    telefono: "",
    direccion: "",
    estado: "activo" as "activo" | "pasivo",
    tipo_prestamo: "" as keyof typeof COMISIONES_POR_TIPO,
    monto_credito: "",
    fecha_otorgamiento: "",
    porcentaje_comision: "",
    observaciones: "",
  })

  const [errors, setErrors] = useState<Record<string, string>>({})

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }

    // Auto-completar porcentaje de comisión cuando se selecciona tipo de préstamo
    if (field === "tipo_prestamo" && value) {
      const porcentajeDefecto = COMISIONES_POR_TIPO[value as keyof typeof COMISIONES_POR_TIPO]?.porcentaje_por_defecto
      if (porcentajeDefecto) {
        setFormData((prev) => ({
          ...prev,
          [field]: value,
          porcentaje_comision: (porcentajeDefecto * 100).toString(),
        }))
      }
    }

    // Validar DNI en tiempo real
    if (field === "dni" && value) {
      const dniLimpio = value.replace(/\D/g, "").slice(0, 8)
      setFormData((prev) => ({ ...prev, [field]: dniLimpio }))
      return
    }

    // Validar teléfono en tiempo real
    if (field === "telefono" && value) {
      const telefonoLimpio = value.replace(/[^\d\-+$$$$\s]/g, "")
      setFormData((prev) => ({ ...prev, [field]: telefonoLimpio }))
      return
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.nombre.trim()) newErrors.nombre = "El nombre es requerido"
    if (!formData.dni.trim()) newErrors.dni = "El DNI es requerido"
    if (!formData.telefono.trim()) newErrors.telefono = "El teléfono es requerido"
    if (!formData.direccion.trim()) newErrors.direccion = "La dirección es requerida"
    if (!formData.tipo_prestamo) newErrors.tipo_prestamo = "El tipo de préstamo es requerido"
    if (!formData.monto_credito || Number.parseFloat(formData.monto_credito) <= 0) {
      newErrors.monto_credito = "El monto de crédito debe ser mayor a 0"
    }
    if (!formData.fecha_otorgamiento) newErrors.fecha_otorgamiento = "La fecha de otorgamiento es requerida"

    // Validar DNI único
    const sociosExistentes = JSON.parse(localStorage.getItem("socios") || "[]")
    const dniExiste = sociosExistentes.some((s: Socio) => s.dni === formData.dni.trim())
    if (dniExiste) newErrors.dni = "Ya existe un socio con este DNI"

    // Validar formato de DNI
    if (formData.dni.trim().length < 7 || formData.dni.trim().length > 8) {
      newErrors.dni = "El DNI debe tener entre 7 y 8 dígitos"
    }

    if (
      formData.porcentaje_comision &&
      (Number.parseFloat(formData.porcentaje_comision) <= 0 || Number.parseFloat(formData.porcentaje_comision) > 100)
    ) {
      newErrors.porcentaje_comision = "El porcentaje debe estar entre 0.1% y 100%"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    const nuevoSocio: Socio = {
      id: Date.now().toString(),
      nombre: formData.nombre.trim(),
      dni: formData.dni.trim(),
      telefono: formData.telefono.trim(),
      direccion: formData.direccion.trim(),
      estado: formData.estado,
      tipo_prestamo: formData.tipo_prestamo,
      monto_credito: Number.parseFloat(formData.monto_credito),
      fecha_otorgamiento: formData.fecha_otorgamiento,
      porcentaje_comision: formData.porcentaje_comision
        ? Number.parseFloat(formData.porcentaje_comision) / 100
        : undefined,
      observaciones: formData.observaciones.trim() || undefined,
      fecha_creacion: new Date().toISOString(),
    }

    // Guardar en localStorage
    const sociosExistentes = JSON.parse(localStorage.getItem("socios") || "[]")
    const sociosActualizados = [...sociosExistentes, nuevoSocio]
    localStorage.setItem("socios", JSON.stringify(sociosActualizados))

    router.push("/socios")
  }

  const porcentajesDisponibles = formData.tipo_prestamo
    ? COMISIONES_POR_TIPO[formData.tipo_prestamo]?.porcentajes_posibles || []
    : []

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <MobileHeader title="Nuevo Socio" showBack backHref="/socios" />

      <main className="px-4 py-6">
        <Card className="shadow-pink border-pink">
          <CardHeader>
            <CardTitle className="text-lg">Información del Socio</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Información personal */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="nombre">Nombre *</Label>
                  <Input
                    id="nombre"
                    value={formData.nombre}
                    onChange={(e) => handleInputChange("nombre", e.target.value)}
                    className={`h-12 ${errors.nombre ? "border-red-500" : ""}`}
                  />
                  {errors.nombre && <p className="text-sm text-red-500">{errors.nombre}</p>}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="dni">DNI *</Label>
                    <Input
                      id="dni"
                      value={formData.dni}
                      onChange={(e) => handleInputChange("dni", e.target.value)}
                      className={`h-12 ${errors.dni ? "border-red-500" : ""}`}
                      placeholder="12345678"
                      maxLength={8}
                    />
                    {errors.dni && <p className="text-sm text-red-500">{errors.dni}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="telefono">Teléfono *</Label>
                    <Input
                      id="telefono"
                      value={formData.telefono}
                      onChange={(e) => handleInputChange("telefono", e.target.value)}
                      className={`h-12 ${errors.telefono ? "border-red-500" : ""}`}
                      placeholder="11-1234-5678"
                    />
                    {errors.telefono && <p className="text-sm text-red-500">{errors.telefono}</p>}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="direccion">Dirección *</Label>
                  <Input
                    id="direccion"
                    value={formData.direccion}
                    onChange={(e) => handleInputChange("direccion", e.target.value)}
                    className={`h-12 ${errors.direccion ? "border-red-500" : ""}`}
                  />
                  {errors.direccion && <p className="text-sm text-red-500">{errors.direccion}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="estado">Estado *</Label>
                  <Select value={formData.estado} onValueChange={(value) => handleInputChange("estado", value)}>
                    <SelectTrigger className="h-12">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="activo">Activo</SelectItem>
                      <SelectItem value="pasivo">Pasivo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Información del préstamo */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="tipo_prestamo">Tipo de Préstamo *</Label>
                  <Select
                    value={formData.tipo_prestamo}
                    onValueChange={(value) => handleInputChange("tipo_prestamo", value)}
                  >
                    <SelectTrigger className={`h-12 ${errors.tipo_prestamo ? "border-red-500" : ""}`}>
                      <SelectValue placeholder="Seleccionar tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      {TIPOS_PRESTAMO.map((tipo) => (
                        <SelectItem key={tipo} value={tipo}>
                          {tipo}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.tipo_prestamo && <p className="text-sm text-red-500">{errors.tipo_prestamo}</p>}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="monto_credito">Monto de Crédito *</Label>
                    <Input
                      id="monto_credito"
                      type="number"
                      step="0.01"
                      value={formData.monto_credito}
                      onChange={(e) => handleInputChange("monto_credito", e.target.value)}
                      className={`h-12 ${errors.monto_credito ? "border-red-500" : ""}`}
                    />
                    {errors.monto_credito && <p className="text-sm text-red-500">{errors.monto_credito}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="fecha_otorgamiento">Fecha *</Label>
                    <Input
                      id="fecha_otorgamiento"
                      type="date"
                      value={formData.fecha_otorgamiento}
                      onChange={(e) => handleInputChange("fecha_otorgamiento", e.target.value)}
                      className={`h-12 ${errors.fecha_otorgamiento ? "border-red-500" : ""}`}
                    />
                    {errors.fecha_otorgamiento && <p className="text-sm text-red-500">{errors.fecha_otorgamiento}</p>}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="porcentaje_comision">Porcentaje de Comisión (%)</Label>
                  <div className="relative">
                    <Input
                      id="porcentaje_comision"
                      type="number"
                      step="0.1"
                      min="0"
                      max="100"
                      value={formData.porcentaje_comision}
                      onChange={(e) => handleInputChange("porcentaje_comision", e.target.value)}
                      placeholder="Ej: 7.0"
                      className="h-12 pr-12"
                    />
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                      <span className="text-sm text-muted-foreground">%</span>
                    </div>
                  </div>
                  {formData.tipo_prestamo && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {porcentajesDisponibles.map((p) => (
                        <Button
                          key={p}
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleInputChange("porcentaje_comision", (p * 100).toString())}
                          className="text-xs"
                        >
                          {(p * 100).toFixed(1)}%
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="observaciones">Observaciones</Label>
                <Textarea
                  id="observaciones"
                  value={formData.observaciones}
                  onChange={(e) => handleInputChange("observaciones", e.target.value)}
                  rows={3}
                  className="resize-none"
                />
              </div>

              <div className="space-y-3 pt-4">
                <Button type="submit" className="w-full h-12">
                  <Save className="h-4 w-4 mr-2" />
                  Guardar Socio
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full h-12 bg-transparent"
                  onClick={() => router.back()}
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>

      <MobileNavigation />
    </div>
  )
}
