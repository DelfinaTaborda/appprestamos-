"use client"

import { useState, useEffect } from "react"
import type { Socio, Tarea } from "@/lib/types"
import { obtenerResumenMensual, formatearMoneda } from "@/lib/utils-app"
import { MobileNavigation } from "@/components/mobile-navigation"
import { MobileHeader } from "@/components/mobile-header"
import { MobileSocioCard } from "@/components/mobile-socio-card"
import { MobileTareaCard } from "@/components/mobile-tarea-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, DollarSign, TrendingUp, AlertCircle, Plus } from "lucide-react"
import Link from "next/link"

export default function Dashboard() {
  const [socios, setSocios] = useState<Socio[]>([])
  const [tareas, setTareas] = useState<Tarea[]>([])

  useEffect(() => {
    // Cargar datos del localStorage
    const sociosGuardados = localStorage.getItem("socios")
    const tareasGuardadas = localStorage.getItem("tareas")

    if (sociosGuardados) {
      setSocios(JSON.parse(sociosGuardados))
    }
    if (tareasGuardadas) {
      setTareas(JSON.parse(tareasGuardadas))
    }
  }, [])

  const resumen = obtenerResumenMensual(socios)
  const tareasVencidas = tareas.filter((t) => new Date(t.fecha_vencimiento) < new Date() && !t.completada).length
  const tareasProximas = tareas.filter((t) => {
    const fechaVencimiento = new Date(t.fecha_vencimiento)
    const hoy = new Date()
    const diasHastaVencimiento = (fechaVencimiento.getTime() - hoy.getTime()) / (1000 * 60 * 60 * 24)
    return diasHastaVencimiento <= 7 && diasHastaVencimiento > 0 && !t.completada
  }).length

  const sociosRecientes = socios
    .sort((a, b) => new Date(b.fecha_creacion).getTime() - new Date(a.fecha_creacion).getTime())
    .slice(0, 3)

  const tareasRecientes = tareas
    .filter((t) => !t.completada)
    .sort((a, b) => new Date(a.fecha_vencimiento).getTime() - new Date(b.fecha_vencimiento).getTime())
    .slice(0, 3)

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <MobileHeader title="Gestión de Socios" />

      <main className="px-4 py-6 space-y-6">
        {/* Métricas principales */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="shadow-pink border-pink">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">Socios</CardTitle>
                <Users className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-gradient-pink">{resumen.totalSocios}</div>
              <p className="text-xs text-muted-foreground">{resumen.sociosActivos} activos</p>
            </CardContent>
          </Card>

          <Card className="shadow-pink border-pink">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">Comisiones</CardTitle>
                <DollarSign className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-gradient-pink">{formatearMoneda(resumen.totalGeneral)}</div>
              <p className="text-xs text-muted-foreground">Este mes</p>
            </CardContent>
          </Card>

          <Card className="shadow-pink border-pink">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">Nuevos</CardTitle>
                <TrendingUp className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-gradient-pink">{resumen.sociosNuevos}</div>
              <p className="text-xs text-muted-foreground">Este mes</p>
            </CardContent>
          </Card>

          <Card className="shadow-pink border-pink">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">Tareas</CardTitle>
                <AlertCircle className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-red-600">{tareasVencidas}</div>
              <p className="text-xs text-muted-foreground">{tareasProximas} próximas</p>
            </CardContent>
          </Card>
        </div>

        {/* Acciones rápidas */}
        <div className="grid grid-cols-2 gap-3">
          <Button asChild className="h-12">
            <Link href="/socios/nuevo">
              <Plus className="h-4 w-4 mr-2" />
              Nuevo Socio
            </Link>
          </Button>
          <Button variant="outline" asChild className="h-12 bg-transparent">
            <Link href="/tareas/nueva">
              <Plus className="h-4 w-4 mr-2" />
              Nueva Tarea
            </Link>
          </Button>
        </div>

        {/* Socios recientes */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Socios Recientes</h2>
            <Button variant="outline" size="sm" asChild>
              <Link href="/socios">Ver todos</Link>
            </Button>
          </div>
          <div className="space-y-3">
            {sociosRecientes.length > 0 ? (
              sociosRecientes.map((socio) => <MobileSocioCard key={socio.id} socio={socio} />)
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center py-8">
                  <p className="text-muted-foreground text-sm">No hay socios registrados</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Tareas pendientes */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Tareas Pendientes</h2>
            <Button variant="outline" size="sm" asChild>
              <Link href="/tareas">Ver todas</Link>
            </Button>
          </div>
          <div className="space-y-3">
            {tareasRecientes.length > 0 ? (
              tareasRecientes.map((tarea) => <MobileTareaCard key={tarea.id} tarea={tarea} />)
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center py-8">
                  <p className="text-muted-foreground text-sm">No hay tareas pendientes</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>

      <MobileNavigation />
    </div>
  )
}
