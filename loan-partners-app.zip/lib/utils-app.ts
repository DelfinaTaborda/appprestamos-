import type { Socio } from "./types"
import { COMISIONES_POR_TIPO } from "./data"

export function calcularComision(socio: Socio): number {
  const porcentaje = socio.porcentaje_comision || COMISIONES_POR_TIPO[socio.tipo_prestamo].porcentaje_por_defecto
  return socio.monto_credito * porcentaje
}

export function formatearMoneda(monto: number): string {
  return new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: "ARS",
  }).format(monto)
}

export function formatearPorcentaje(porcentaje: number): string {
  return `${(porcentaje * 100).toFixed(1)}%`
}

export function obtenerResumenMensual(socios: Socio[]) {
  const sociosActivos = socios.filter((s) => s.estado === "activo")

  const comisionesPorTipo = sociosActivos.reduce(
    (acc, socio) => {
      const tipo = socio.tipo_prestamo
      if (!acc[tipo]) {
        acc[tipo] = { total: 0, cantidad: 0 }
      }
      acc[tipo].total += calcularComision(socio)
      acc[tipo].cantidad += 1
      return acc
    },
    {} as Record<string, { total: number; cantidad: number }>,
  )

  const totalGeneral = Object.values(comisionesPorTipo).reduce((sum, item) => sum + item.total, 0)

  const fechaActual = new Date()
  const inicioMes = new Date(fechaActual.getFullYear(), fechaActual.getMonth(), 1)
  const sociosNuevos = socios.filter((s) => new Date(s.fecha_creacion) >= inicioMes).length

  return {
    comisionesPorTipo,
    totalGeneral,
    sociosNuevos,
    totalSocios: socios.length,
    sociosActivos: sociosActivos.length,
  }
}
