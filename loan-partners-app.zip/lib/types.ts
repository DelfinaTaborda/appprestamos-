export interface Socio {
  id: string
  nombre: string
  dni: string
  telefono: string
  direccion: string
  estado: "activo" | "pasivo"
  tipo_prestamo: "MUPER" | "REFI" | "Nacional" | "SiDeCreer" | "Nuevo Socio"
  monto_credito: number
  fecha_otorgamiento: string
  porcentaje_comision?: number
  observaciones?: string
  fecha_creacion: string
}

export interface Tarea {
  id: string
  titulo: string
  descripcion: string
  fecha_vencimiento: string
  completada: boolean
  socio_id?: string
  prioridad: "baja" | "media" | "alta"
  fecha_creacion: string
}

export interface ComisionConfig {
  porcentajes_posibles: number[]
  porcentaje_por_defecto: number
}

export interface ComisionesPorTipo {
  [key: string]: ComisionConfig
}
