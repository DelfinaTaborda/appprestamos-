import type { ComisionesPorTipo } from "./types"

export const COMISIONES_POR_TIPO: ComisionesPorTipo = {
  MUPER: {
    porcentajes_posibles: [0.06, 0.07, 0.08],
    porcentaje_por_defecto: 0.07,
  },
  REFI: {
    porcentajes_posibles: [0.03],
    porcentaje_por_defecto: 0.03,
  },
  Nacional: {
    porcentajes_posibles: [0.03],
    porcentaje_por_defecto: 0.03,
  },
  SiDeCreer: {
    porcentajes_posibles: [0.05],
    porcentaje_por_defecto: 0.05,
  },
  "Nuevo Socio": {
    porcentajes_posibles: [0.02, 0.03, 0.04],
    porcentaje_por_defecto: 0.03,
  },
}

export const TIPOS_PRESTAMO = Object.keys(COMISIONES_POR_TIPO) as Array<keyof typeof COMISIONES_POR_TIPO>
