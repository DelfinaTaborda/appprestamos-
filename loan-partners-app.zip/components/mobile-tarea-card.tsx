"use client"

import type { Tarea } from "@/lib/types"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Calendar, AlertCircle, CheckCircle2, Clock } from "lucide-react"

interface MobileTareaCardProps {
  tarea: Tarea
  onToggleComplete?: (id: string) => void
  onEdit?: (tarea: Tarea) => void
}

export function MobileTareaCard({ tarea, onToggleComplete, onEdit }: MobileTareaCardProps) {
  const fechaVencimiento = new Date(tarea.fecha_vencimiento)
  const hoy = new Date()
  const esVencida = fechaVencimiento < hoy && !tarea.completada
  const esProxima = fechaVencimiento.getTime() - hoy.getTime() < 7 * 24 * 60 * 60 * 1000 && !tarea.completada

  const getPrioridadColor = (prioridad: string) => {
    switch (prioridad) {
      case "alta":
        return "destructive"
      case "media":
        return "default"
      case "baja":
        return "secondary"
      default:
        return "secondary"
    }
  }

  const getStatusIcon = () => {
    if (tarea.completada) return <CheckCircle2 className="h-4 w-4 text-green-600" />
    if (esVencida) return <AlertCircle className="h-4 w-4 text-red-600" />
    if (esProxima) return <Clock className="h-4 w-4 text-yellow-600" />
    return <Calendar className="h-4 w-4 text-muted-foreground" />
  }

  return (
    <Card className={`w-full shadow-pink border-pink ${tarea.completada ? "opacity-75" : ""}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start gap-3">
          {onToggleComplete && (
            <Checkbox checked={tarea.completada} onCheckedChange={() => onToggleComplete(tarea.id)} className="mt-1" />
          )}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between mb-2">
              <h3 className={`font-medium text-sm ${tarea.completada ? "line-through" : ""} truncate`}>
                {tarea.titulo}
              </h3>
              <Badge variant={getPrioridadColor(tarea.prioridad) as any} className="ml-2 text-xs">
                {tarea.prioridad}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground line-clamp-2">{tarea.descripcion}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-xs">
          {getStatusIcon()}
          <span className={esVencida ? "text-red-600 font-medium" : "text-muted-foreground"}>
            {fechaVencimiento.toLocaleDateString("es-AR")}
          </span>
        </div>

        {esVencida && <div className="text-xs text-red-600 font-medium">¡Vencida!</div>}
        {esProxima && !esVencida && <div className="text-xs text-yellow-600 font-medium">Vence pronto</div>}

        {onEdit && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => onEdit(tarea)}
            className="w-full border-primary text-primary hover:bg-primary hover:text-white text-xs"
          >
            Editar
          </Button>
        )}
      </CardContent>
    </Card>
  )
}
