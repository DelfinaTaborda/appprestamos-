"use client"

import Link from "next/link"
import type { Socio } from "@/lib/types"
import { calcularComision, formatearMoneda, formatearPorcentaje } from "@/lib/utils-app"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Eye, Edit, Phone, MapPin, DollarSign } from "lucide-react"

interface MobileSocioCardProps {
  socio: Socio
  onEdit?: (socio: Socio) => void
}

export function MobileSocioCard({ socio, onEdit }: MobileSocioCardProps) {
  const comision = calcularComision(socio)

  return (
    <Card className="w-full shadow-pink border-pink hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-primary truncate">{socio.nombre}</h3>
            <p className="text-sm text-muted-foreground">DNI: {socio.dni}</p>
            <p className="text-xs text-muted-foreground mt-1">{socio.tipo_prestamo}</p>
          </div>
          <Badge
            className={
              socio.estado === "activo"
                ? "bg-primary hover:bg-primary/80 text-white"
                : "bg-primary/70 hover:bg-primary/60 text-white"
            }
          >
            {socio.estado}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Información financiera */}
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="flex items-center gap-2">
            <DollarSign className="h-4 w-4 text-primary" />
            <div>
              <p className="text-xs text-muted-foreground">Crédito</p>
              <p className="font-medium">{formatearMoneda(socio.monto_credito)}</p>
            </div>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Comisión</p>
            <p className="font-medium text-green-600">{formatearMoneda(comision)}</p>
            <p className="text-xs text-muted-foreground">{formatearPorcentaje(socio.porcentaje_comision || 0)}</p>
          </div>
        </div>

        {/* Información de contacto */}
        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4 text-muted-foreground" />
            <span className="truncate">{socio.telefono}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-muted-foreground" />
            <span className="truncate text-xs">{socio.direccion}</span>
          </div>
        </div>

        {/* Botones de acción */}
        <div className="flex gap-2 pt-2">
          <Button
            variant="outline"
            size="sm"
            asChild
            className="flex-1 border-primary text-primary hover:bg-primary hover:text-white bg-transparent"
          >
            <Link href={`/socios/${socio.id}`}>
              <Eye className="h-4 w-4 mr-1" />
              Ver
            </Link>
          </Button>
          <Button
            variant="outline"
            size="sm"
            asChild
            className="flex-1 border-primary text-primary hover:bg-primary hover:text-white bg-transparent"
          >
            <Link href={`/socios/${socio.id}/editar`}>
              <Edit className="h-4 w-4 mr-1" />
              Editar
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
