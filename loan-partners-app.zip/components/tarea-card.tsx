"use client"

import type { Tarea } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Calendar, AlertCircle, CheckCircle2, Clock } from "lucide-react"

interface TareaCardProps {
  tarea: Tarea
  onToggleComplete?: (id: string) => void
  onEdit?: (tarea: Tarea) => void
}

export function TareaCard({ tarea, onToggleComplete, onEdit }: TareaCardProps) {
  const fechaVencimiento = new Date(tarea.fecha_vencimiento)
  const hoy = new Date()
  const esVencida = fechaVencimiento < hoy && !tarea.completada
  const esProxima = fechaVencimiento.getTime() - hoy.getTime() < 7 * 24 * 60 * 60 * 1000 && !tarea.completada

  const getPrioridadColor = (prioridad: string) => {
    switch (prioridad) {
      case "alta":
        return "destructive"
      case "media":
        return "default"
      case "baja":
        return "secondary"
      default:
        return "secondary"
    }
  }

  const getStatusIcon = () => {
    if (tarea.completada) return <CheckCircle2 className="h-4 w-4 text-green-600" />
    if (esVencida) return <AlertCircle className="h-4 w-4 text-red-600" />
    if (esProxima) return <Clock className="h-4 w-4 text-yellow-600" />
    return <Calendar className="h-4 w-4 text-muted-foreground" />
  }

  return (
    <Card className={`w-full shadow-pink border-pink ${tarea.completada ? "opacity-75" : ""}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            {onToggleComplete && (
              <Checkbox
                checked={tarea.completada}
                onCheckedChange={() => onToggleComplete(tarea.id)}
                className="mt-1"
              />
            )}
            <div>
              <CardTitle className={`text-lg ${tarea.completada ? "line-through" : ""}`}>{tarea.titulo}</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">{tarea.descripcion}</p>
            </div>
          </div>
          <Badge variant={getPrioridadColor(tarea.prioridad) as any}>{tarea.prioridad}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-sm">
          {getStatusIcon()}
          <span className={esVencida ? "text-red-600 font-medium" : "text-muted-foreground"}>
            Vence: {fechaVencimiento.toLocaleDateString("es-AR")}
          </span>
        </div>

        {esVencida && <div className="text-sm text-red-600 font-medium">¡Tarea vencida!</div>}

        {esProxima && !esVencida && <div className="text-sm text-yellow-600 font-medium">Vence pronto</div>}

        {onEdit && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => onEdit(tarea)}
            className="border-primary text-primary hover:bg-primary hover:text-white"
          >
            Editar
          </Button>
        )}
      </CardContent>
    </Card>
  )
}
