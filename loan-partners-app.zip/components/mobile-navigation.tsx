"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Users, CheckSquare, BarChart3, Home } from "lucide-react"
import { useState } from "react"

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Socios", href: "/socios", icon: Users },
  { name: "Tareas", href: "/tareas", icon: CheckSquare },
  { name: "Reportes", href: "/reportes", icon: BarChart3 },
]

export function MobileNavigation() {
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      {/* Navegación móvil - Bottom Tab Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-pink md:hidden">
        <div className="grid grid-cols-4 h-16">
          {navigation.map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex flex-col items-center justify-center space-y-1 ${
                  isActive
                    ? "text-primary bg-primary/10"
                    : "text-muted-foreground hover:text-primary hover:bg-primary/5"
                }`}
              >
                <Icon className="h-5 w-5" />
                <span className="text-xs font-medium">{item.name}</span>
              </Link>
            )
          })}
        </div>
      </div>

      {/* Navegación desktop - Header */}
      <div className="hidden md:flex space-x-2">
        {navigation.map((item) => {
          const Icon = item.icon
          return (
            <Button
              key={item.name}
              variant={pathname === item.href ? "default" : "ghost"}
              asChild
              className={`flex items-center gap-2 ${
                pathname === item.href ? "bg-primary text-white shadow-pink" : "hover:bg-primary/10 hover:text-primary"
              }`}
            >
              <Link href={item.href}>
                <Icon className="h-4 w-4" />
                {item.name}
              </Link>
            </Button>
          )
        })}
      </div>
    </>
  )
}
