"use client"

import Link from "next/link"
import type { Socio } from "@/lib/types"
import { calcularComision, formatearMoneda, formatearPorcentaje } from "@/lib/utils-app"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Eye, Edit, Phone, MapPin } from "lucide-react"

interface SocioCardProps {
  socio: Socio
  onEdit?: (socio: Socio) => void
}

export function SocioCard({ socio, onEdit }: SocioCardProps) {
  const comision = calcularComision(socio)

  return (
    <Card className="w-full shadow-pink border-pink hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg text-primary">{socio.nombre}</CardTitle>
            <p className="text-sm text-muted-foreground">DNI: {socio.dni}</p>
          </div>
          <Badge
            className={
              socio.estado === "activo"
                ? "bg-primary hover:bg-primary/80 text-white"
                : "bg-primary/70 hover:bg-primary/60 text-white"
            }
          >
            {socio.estado}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="font-medium">Tipo de Préstamo</p>
            <p className="text-muted-foreground">{socio.tipo_prestamo}</p>
          </div>
          <div>
            <p className="font-medium">Monto Crédito</p>
            <p className="text-muted-foreground">{formatearMoneda(socio.monto_credito)}</p>
          </div>
          <div>
            <p className="font-medium">Comisión</p>
            <p className="text-muted-foreground">{formatearMoneda(comision)}</p>
          </div>
          <div>
            <p className="font-medium">Porcentaje</p>
            <p className="text-muted-foreground">{formatearPorcentaje(socio.porcentaje_comision || 0)}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Phone className="h-4 w-4" />
          <span>{socio.telefono}</span>
        </div>

        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4" />
          <span className="truncate">{socio.direccion}</span>
        </div>

        <div className="flex gap-2 pt-2">
          <Button
            variant="outline"
            size="sm"
            asChild
            className="flex-1 border-primary text-primary hover:bg-primary hover:text-white bg-transparent"
          >
            <Link href={`/socios/${socio.id}`}>
              <Eye className="h-4 w-4 mr-1" />
              Ver
            </Link>
          </Button>
          <Button
            variant="outline"
            size="sm"
            asChild
            className="flex-1 border-primary text-primary hover:bg-primary hover:text-white bg-transparent"
          >
            <Link href={`/socios/${socio.id}/editar`}>
              <Edit className="h-4 w-4 mr-1" />
              Editar
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
