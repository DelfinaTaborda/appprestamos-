"use client"

import { Button } from "@/components/ui/button"
import { ArrowLeft, Plus } from "lucide-react"
import Link from "next/link"

interface MobileHeaderProps {
  title: string
  showBack?: boolean
  backHref?: string
  showAdd?: boolean
  addHref?: string
  addLabel?: string
}

export function MobileHeader({ title, showBack, backHref, showAdd, addHref, addLabel }: MobileHeaderProps) {
  return (
    <header className="sticky top-0 z-40 bg-white border-b border-pink shadow-sm">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-3">
          {showBack && backHref && (
            <Button variant="ghost" size="sm" asChild className="p-2">
              <Link href={backHref}>
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
          )}
          <h1 className="text-lg font-bold text-primary truncate">{title}</h1>
        </div>

        {showAdd && addHref && (
          <Button size="sm" asChild className="bg-primary hover:bg-primary/90 shadow-pink">
            <Link href={addHref}>
              <Plus className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">{addLabel}</span>
            </Link>
          </Button>
        )}
      </div>
    </header>
  )
}
